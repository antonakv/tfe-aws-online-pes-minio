
This is a support bundle generated from the replicated daemon. The version of the support bundle container should be
present within each bundle directory at VERSION.json.

Documentation is available online at https://help.replicated.com/docs/packaging-an-application/support-bundle and
includes details on how to include custom data in support bundles generated through replicated for your application.
